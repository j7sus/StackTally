Hello,

Thank for downloading SQUARE SPACE.

NOTE:

By installing or using this font, you are agree to the Product Usage Agreement:


- This demo font is ONLY for PERSONAL USE. NO COMMERCIAL USE ALLOWED!


- Here is the link to purchase full version and commercial license:

  + Creative Market: https://creativemarket.com/InventypeStudio/7239717-Square-Space-Futuristic-Font

  + Etsy: https://www.etsy.com/listing/1241048638/square-space-futuristic-font-san-serif
  + Creative Fabrica: https://www.creativefabrica.com/product/square-space-3/
- For Corporate use you have to purchase Corporate license

- Any donation are very appreciated. Paypal account for donation : https://paypal.me/KhusnulUlum
Please visit our store for more amazing fonts :
- Creeative Market: https://creativemarket.com/InventypeStudio
- Etsy: https://www.etsy.com/shop/InventypeStudio
- Creative Fabrica: https://www.creativefabrica.com/designer/inventype-studio/
Thank you.




-------------------

INDONESIA:


Dengan meng-install font ini, anda dianggap mengerti dan menyetujui semua syarat dan ketentuan penggunaan font dibawah ini:


- Font demo ini hanya dapat digunakan untuk keperluan "Personal Use"/kebutuhan pribadi, atau untuk keperluan yang sifatnya tidak "komersil", alias tidak menghasilkan profit atau keuntungan dari hasil memanfaatkan/menggunakan font kami. Baik itu untuk individu, Agensi Desain Grafis, Percetakan, Distro atau Perusahaan/Korporasi.


- Silakan gunakan lisensi komersial dengan membeli melalui link ini : 

https://creativemarket.com/KhusnulUlum/7239717-Square-Space-Futuristic-Font



- Dengan hanya lisensi "Personal Use", DILARANG KERAS menggunakan atau memanfaatkan font ini untuk kepeluan Komersial, baik itu untuk Iklan, Promosi, TV, Film, Video, Motion Graphics, Youtube, Desain kaos distro atau untuk Kemasan Produk (baik Fisik ataupun Digital) atau Media apapun dengan tujuan menghasilkan profit/keuntungan.


- Untuk penggunaan keperluan Perusahaan/Korporasi silakan menggunakan Corporate License.


- Menggunakan font ini dengan lisensi "Personal Use" untuk kepentingan Komersial apapun bentuknya TANPA IZIN dari kami, akan dikenakan biaya CORPORATE LICENSE.

Informasi tentang Lisensi apa yang akan anda perlukan, silahkan menghubungi kami di : khusnululum05@gmail.com



Terima kasih.
